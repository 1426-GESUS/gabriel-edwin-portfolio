# Gabriel Edwin — Practice Work Samples

These are practice projects using fictional data, created to demonstrate data entry, Excel reporting, and document formatting skills.

- `data-entry-practice.csv` — fictional records for data organization.
- `excel-sales-practice.xlsx` — sales report with spreadsheet formulas.
- `document-formatting-practice.docx` — formatted business report.

These are practice samples, not paid client work. Review and customize them before sharing with potential clients.
